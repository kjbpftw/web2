<script>
import Blog from '../index.vue';

export default {
  extends: Blog,
};
</script>
